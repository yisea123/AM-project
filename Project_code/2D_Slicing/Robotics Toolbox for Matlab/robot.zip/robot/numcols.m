%
% NUMCOLS(m)
%
%	Return the number of columns in the matrix m
%
function c = numcols(m)
	[x,c] = size(m);
