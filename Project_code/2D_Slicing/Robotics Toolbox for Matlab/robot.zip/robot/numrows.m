%
% NUMROWS(m)
%
%	Return the number of rows in the matrix m
%
function r = numrows(m)
	[r,x] = size(m);
