function contours = Extract_envelope(F, V, N)
